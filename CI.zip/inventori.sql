-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 04 Jan 2023 pada 11.13
-- Versi server: 10.4.14-MariaDB
-- Versi PHP: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventori`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE `barang` (
  `kd_barang` char(6) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `kd_jenis` char(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`kd_barang`, `nama_barang`, `kd_jenis`) VALUES
('BR0001', 'Acrylic Epoxy Spray Paint Silver', 'KJ001'),
('BR0002', 'Alkohol 70%', 'KJ008'),
('BR0003', 'Antena N Wifi omni indoor', 'KJ005'),
('BR0004', 'Antena Tp-Link Wifi Omni Indoor', 'KJ005'),
('BR0005', 'Artic Spary Paint Black', 'KJ001'),
('BR0006', 'Baterai AA ABC', 'KJ003'),
('BR0007', 'Baterai AA Alkaline', 'KJ003'),
('BR0008', 'Baterai AAA Eveready', 'KJ003'),
('BR0009', 'Baterai CMOS', 'KJ003'),
('BR0010', 'Baterai Eveready 9 volt', 'KJ003'),
('BR0011', 'Baterai Hi-Watt 9 volt', 'KJ003'),
('BR0012', 'Baterai Laptop TOSHIBA', 'KJ003'),
('BR0013', 'Cable Tester', 'KJ015'),
('BR0014', 'CPU Rusak', 'KJ006'),
('BR0015', 'Double Tape', 'KJ007'),
('BR0016', 'Intel Core i3-4170', 'KJ004'),
('BR0017', 'Kabel Adapter 9V&12V', 'KJ002'),
('BR0018', 'Kabel Console Cisco USB to RJ45', 'KJ002'),
('BR0019', 'Kabel Jumper', 'KJ002'),
('BR0020', 'Kabel Jumper Female To Female', 'KJ002'),
('BR0021', 'Kabel Jumper Female To Male', 'KJ002'),
('BR0022', 'Kabel LAN', 'KJ002'),
('BR0023', 'Kabel Listri NYM', 'KJ002'),
('BR0024', 'Kabel Serial ATA', 'KJ002'),
('BR0025', 'Kabel USB To Type A', 'KJ002'),
('BR0026', 'Kabel USB To Type B Arduino', 'KJ002'),
('BR0027', 'Kabel VGA', 'KJ002'),
('BR0028', 'Kabel Fiber Optik', 'KJ002'),
('BR0029', 'Keyboard', 'KJ016'),
('BR0030', 'Keyboard Alcatros', 'KJ016'),
('BR0031', 'Konektor SC APC', 'KJ012'),
('BR0032', 'Konektor SC UPC', 'KJ012'),
('BR0033', 'Connector RJ45', 'KJ012'),
('BR0034', 'LED 3mm', 'KJ011'),
('BR0035', 'LED 5mm', 'KJ011'),
('BR0036', 'Lampu National Light Capsule 25W', 'KJ011'),
('BR0037', 'DHT 11', 'KJ010'),
('BR0038', 'Sensor Cahaya', 'KJ010'),
('BR0039', 'Sensor Infrared', 'KJ010'),
('BR0040', 'Sensor PIR', 'KJ010'),
('BR0041', 'Sensor Ultrasonic', 'KJ010'),
('BR0042', 'Sound Module/Sensor suara', 'KJ010'),
('BR0043', 'Display LCD', 'KJ017'),
('BR0044', 'Display LED Dot Matrix 32X8', 'KJ017'),
('BR0045', 'LED 7 Segment Display', 'KJ017'),
('BR0046', 'LED Running Text Display', 'KJ017'),
('BR0047', 'Lenovo Computer Display', 'KJ017'),
('BR0048', 'IC Logic 7400', 'KJ018'),
('BR0049', 'IC Logic 7402', 'KJ018'),
('BR0050', 'IC Logic 7404', 'KJ018'),
('BR0051', 'IC Logic 7408', 'KJ018'),
('BR0052', 'IC Logic 74266', 'KJ018'),
('BR0053', 'IC Logic 7432', 'KJ018'),
('BR0054', 'IC Logic 7454', 'KJ018'),
('BR0055', 'IC Logic 7473', 'KJ018'),
('BR0056', 'IC Logic 7474', 'KJ018'),
('BR0057', 'IC Logic 7476', 'KJ018'),
('BR0058', 'IC Logic 7486', 'KJ018'),
('BR0059', 'Multi Tester Besar', 'KJ015'),
('BR0060', 'Multi Tester Kecil', 'KJ015'),
('BR0061', 'D-Link 16 Port DES-1016A', 'KJ019'),
('BR0062', 'D-Link 8 Port Desktop Switch', 'KJ019'),
('BR0063', 'D-Link 8 Port DES-1008A', 'KJ019'),
('BR0064', 'Arduino MEGA', 'KJ020'),
('BR0065', 'Arduino Shield With Bread Board', 'KJ020'),
('BR0066', 'Arduino Trainer Kit', 'KJ020'),
('BR0067', 'Arduino Uno', 'KJ020'),
('BR0068', 'Arduino Uno & Prototype Shield ', 'KJ020'),
('BR0069', 'Hard Disk Samsung 40 GB', 'KJ026'),
('BR0070', 'Hard Disk Seagate 20 GB', 'KJ026'),
('BR0071', 'Hard Disk Seagate 40 GB', 'KJ026'),
('BR0072', 'Hard Disk Seagate 500 GB', 'KJ026'),
('BR0073', 'Hard Disk Seagate 80 GB', 'KJ026'),
('BR0074', 'Hard Disk Western Digital 500 GB', 'KJ026'),
('BR0075', 'Tinta Printer Biru', 'KJ009'),
('BR0076', 'Tinta Printer Hitam', 'KJ009'),
('BR0077', 'Tinta Printer Kuning', 'KJ009'),
('BR0078', 'Tinta Printer Merah ', 'KJ009'),
('BR0079', 'Tinta Spidol Refill ', 'KJ009'),
('BR0080', 'Tp-Link 24 Port Desktop Switch TL-SF1024D ', 'KJ019'),
('BR0081', 'Tp-Link 16 Port TL-SF1016D ', 'KJ019'),
('BR0082', 'Tp-Link 8 Port TL-SF1008D', 'KJ019'),
('BR0083', 'Tp-Link Ethernet Switch 24v Port type TL-SF1024', 'KJ019'),
('BR0084', 'Xbee S2 ', 'KJ022'),
('BR0085', 'Xbee S2C ', 'KJ022'),
('BR0086', 'Xbee S38', 'KJ022'),
('BR0087', 'Xbee Shield Pro', 'KJ022'),
('BR0088', 'Xbee to USB Adapter Foca', 'KJ022'),
('BR0089', 'Yongli Barcode Scanner', 'KJ024'),
('BR0090', 'Rother Board RB2011 Series ', 'KJ013'),
('BR0091', 'Routher Board 951-2n ', 'KJ013'),
('BR0092', 'Routher hAP lite', 'KJ013'),
('BR0093', 'Routher hAP Series', 'KJ013'),
('BR0094', 'Routher type 95Ui 2HnD', 'KJ013'),
('BR0095', 'Mikrotik Routhers and Wireless', 'KJ013'),
('BR0096', 'RTC', 'KJ010'),
('BR0097', 'Papan Breadboard ', 'KJ027'),
('BR0098', 'Papan Breadboard 17X10 ', 'KJ027'),
('BR0099', 'Papan Breadboard 30X10', 'KJ027'),
('BR0100', 'Papan PCB', 'KJ027'),
('BR0101', 'Processor Amd 486', 'KJ004'),
('BR0102', 'Processor Intel Pentium', 'KJ004'),
('BR0103', 'Pylox Nipon Paint', 'KJ001'),
('BR0104', 'Remote infFocus', 'KJ023'),
('BR0105', 'Wireless G-Home Router WRH54G', 'KJ013'),
('BR0106', 'Esp8266 Mod ', 'KJ021'),
('BR0107', 'Esp8266 Mod With NodeMcu base ', 'KJ021'),
('BR0108', 'Esp-WROOM 32', 'KJ021'),
('BR0109', 'Handycam Sony DCR SX22 zoom 70X', 'KJ025'),
('BR0110', 'ProLink 8 Port PSW810', 'KJ019');

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail`
--

CREATE TABLE `detail` (
  `kd_detail` int(11) NOT NULL,
  `kd_barang` char(6) NOT NULL,
  `kd_kondisi` char(2) NOT NULL,
  `jumlah` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `detail`
--

INSERT INTO `detail` (`kd_detail`, `kd_barang`, `kd_kondisi`, `jumlah`) VALUES
(1, 'BR0001', '02', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis_barang`
--

CREATE TABLE `jenis_barang` (
  `kd_jenis` char(5) NOT NULL,
  `jenis` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `jenis_barang`
--

INSERT INTO `jenis_barang` (`kd_jenis`, `jenis`) VALUES
('', ''),
('KJ001', 'cat'),
('KJ002', 'kabel'),
('KJ003', 'Baterai'),
('KJ004', 'Prosesor'),
('KJ005', 'Antena'),
('KJ006', 'CPU'),
('KJ007', 'Perekat'),
('KJ008', 'Pembersih'),
('KJ009', 'Tinta'),
('KJ010', 'Sensor'),
('KJ011', 'Lampu'),
('KJ012', 'konektor'),
('KJ013', 'Routher'),
('KJ014', 'RAM'),
('KJ015', 'Tester'),
('KJ016', 'Keyboard'),
('KJ017', 'Display'),
('KJ018', 'IC'),
('KJ019', 'switch'),
('KJ020', 'Arduino'),
('KJ021', 'ESP'),
('KJ022', 'XBee'),
('KJ023', 'remote'),
('KJ024', 'Scanner'),
('KJ025', 'Kamera'),
('KJ026', 'Penyimpanan'),
('KJ027', 'Papan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kondisi`
--

CREATE TABLE `kondisi` (
  `kd_kondisi` char(2) NOT NULL,
  `kondisi` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kondisi`
--

INSERT INTO `kondisi` (`kd_kondisi`, `kondisi`) VALUES
('01', 'Baru'),
('02', 'Bagus'),
('03', 'Layak Pakai'),
('04', 'rusak'),
('05', 'Rusak Parah'),
('06', 'Lama');

-- --------------------------------------------------------

--
-- Struktur dari tabel `peminjaman`
--

CREATE TABLE `peminjaman` (
  `kd_pinjam` char(5) NOT NULL,
  `username` char(10) NOT NULL,
  `kd_barang` char(6) NOT NULL,
  `tgl_pinjam` date NOT NULL,
  `status_kembali` enum('belum-kembali','kembali') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `peminjaman`
--

INSERT INTO `peminjaman` (`kd_pinjam`, `username`, `kd_barang`, `tgl_pinjam`, `status_kembali`) VALUES
('P0001', '2020610008', 'BR0001', '2022-11-13', 'kembali'),
('P0002', '2020610001', 'BR0003', '2022-11-13', ''),
('P0003', '2020610008', 'BR0014', '2022-11-13', 'kembali');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengembalian`
--

CREATE TABLE `pengembalian` (
  `kd_kembali` int(11) NOT NULL,
  `kd_pinjam` char(5) NOT NULL,
  `tgl_kembali` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pengembalian`
--

INSERT INTO `pengembalian` (`kd_kembali`, `kd_pinjam`, `tgl_kembali`) VALUES
(1, 'P0003', '2022-11-13'),
(2, 'P0001', '2022-11-13');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `username` char(10) NOT NULL,
  `password` varchar(12) NOT NULL,
  `nama` varchar(35) NOT NULL,
  `alamat` varchar(30) NOT NULL,
  `email` varchar(25) NOT NULL,
  `no_hp` varchar(12) NOT NULL,
  `level` enum('admin','client') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`username`, `password`, `nama`, `alamat`, `email`, `no_hp`, `level`) VALUES
('2020610003', '1234', 'wulandaripadang', 'abcefgh', 'asd@gmail.com', '133', 'client'),
('2020610008', 'wulan123', 'Wulan Dari', 'padang', 'wulann@gmail.com', '1213342', 'client'),
('2020610010', 'asd', 'fitri', 'padang', 'as@gmail.com', '1224231', 'client'),
('2020610024', 'wintergirld', 'nabila', 'padang', 'nabila@gmail.com', '082243134228', 'admin'),
('2020610025', 'dream', 'Rahma', 'jalan gajah mada', 'rahma@gmail.com', '081234567812', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`kd_barang`);

--
-- Indeks untuk tabel `detail`
--
ALTER TABLE `detail`
  ADD PRIMARY KEY (`kd_detail`);

--
-- Indeks untuk tabel `jenis_barang`
--
ALTER TABLE `jenis_barang`
  ADD PRIMARY KEY (`kd_jenis`);

--
-- Indeks untuk tabel `kondisi`
--
ALTER TABLE `kondisi`
  ADD PRIMARY KEY (`kd_kondisi`);

--
-- Indeks untuk tabel `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`kd_pinjam`);

--
-- Indeks untuk tabel `pengembalian`
--
ALTER TABLE `pengembalian`
  ADD PRIMARY KEY (`kd_kembali`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `detail`
--
ALTER TABLE `detail`
  MODIFY `kd_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `pengembalian`
--
ALTER TABLE `pengembalian`
  MODIFY `kd_kembali` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
