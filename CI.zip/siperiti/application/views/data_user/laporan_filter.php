<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan User</title>
</head>

<body>
    <center>
        <div class="page-header">
            <h3>Laporan User</h3>
        </div>
        <hr>

        <div class="table-responsive">
            <table border="1" class="table table-striped table-hover tablebordered" id="table-datatable" style="width:75%; text-align:center;">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>username</th>
                        <th>password</th>
                        <th>nama lengkap</th>
                        <th>alamat</th>
                        <th>email</th>
                        <th>no.hp</th>
                        <th>level</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    foreach ($laporan as $data) :
                    ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $data->username ?></td>
                            <td><?= $data->password ?></td>
                            <td><?= $data->nama ?></td>
                            <td><?= $data->alamat ?></td>
                            <td><?= $data->email ?></td>
                            <td><?= $data->no_hp ?></td>
                            <td><?= $data->level ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </center>
</body>

</html>