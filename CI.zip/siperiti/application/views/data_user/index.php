<div class="card-header">
    <a href="<?= base_url('data_user/tambah') ?>" class="btn btn-primary">Tambah Data</a>
    <a href="<?= base_url('data_user/laporan/') ?>" style="float:right;" class="btn btn-info">Cetak</a>
</div>
<table class="table table-striped">
    <thead>
        <th>No</th>
        <th>Username</th>
        <th>Password</th>
        <th>Nama Lengkap</th>
        <th>Alamat</th>
        <th>Email</th>
        <th>No.Hp</th>
        <th>Level</th>
        <th>Aksi</th>
    </thead>
    <tbody>
        <?php
        $no = 1;
        foreach ($user as $data) :
        ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $data->username ?></td>
                <td><?= $data->password ?></td>
                <td><?= $data->nama ?></td>
                <td><?= $data->alamat ?></td>
                <td><?= $data->email ?></td>
                <td><?= $data->no_hp ?></td>
                <td><?= $data->level ?></td>
                <td>
                    <a href="<?= base_url('data_user/ubah/' . $data->username) ?>" class="btn btn-success">Ubah</a>
                    <a href="<?= base_url('data_user/hapus/' . $data->username) ?>" class="btn btn-danger">Hapus</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>