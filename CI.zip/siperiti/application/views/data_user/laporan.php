<div class="page-header">
<h3>Laporan</h3>
</div>
<form method="post" action="<?php echo base_url().'Data_user/laporan'
?>">

</form>
