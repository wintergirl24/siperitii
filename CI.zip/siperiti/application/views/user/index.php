<div class="page-header">
    <h3>Home</h3>
</div>
<div class="row">
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="glyphicon glyphiconfolder-open"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div>Jumlah Barang</div>
                    </div>
                </div>
            </div>
            <a href="<?php echo base_url() . 'admin/barang' ?>">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="glyphicon glyphicon-arrow-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-success">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="glyphicon glyphiconuser"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div>Detail Barang</div>
                    </div>
                </div>
            </div>
            <a href="<?php echo base_url() . 'admin/detail' ?>">
                <div class="panel-footer">
                    <span class="pull-left">View Detail</span>
                    <span class="pull-right"><i class="glyphicon glyphicon-arrow-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-warning">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="glyphicon glyphiconsort"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div>Jenis Barang</div>
                    </div>
                </div>
            </div>
            <a href="<?php echo base_url() . 'admin/jenis_barang' ?>">
                <div class="panel-footer">
                    <span class="pull-left">View jenis_barang</span>
                    <span class="pull-right"><i class="glyphicon glyphicon-arrow-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
   
<!-- /.row -->