<div class="page-header">
    <h3>user</h3>
</div>
<a href="<?php echo base_url() . 'user/user_add'; ?>" class="btn btn-primary btn-sm"><span class="glyphicon glyphicon-plus"></span>user</a>
<br /><br />
<div class="table-responsive">
    <table class="table table-bordered table-striped table-hover" id="table-datatable">
        <thead>
            <tr>
                <th>No</th>
                <th>Username</th>
                <th>Password</th>
                <th>Nama</th>
                <th>Alamat</th>
                <th>Email</th>
                <th>No hp</th>
                <th>Level</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            foreach ($user as $u) {
            ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo $u->username ?></td>
                    <td><?php echo $u->Password ?></td>
                    <td><?php echo $u->Nama ?></td>
                    <td><?php echo $u->Alamat ?></td>
                    <td><?php echo $u->Email ?></td>
                    <td><?php echo $u->No_hp ?></td>
                    <td><?php echo $u->Level ?></td>
                    <td>
                        <a class="btn btn-warning btn-sm" href="<?php echo base_url() . 'user/user_edit/' . $u->username;
                                                                ?>"><span class="glyphicon glyphicon-plus"></span> Edit</a>
                        <a class="btn btn-danger btn-sm" href="<?php echo base_url() . 'user/user_hapus/' . $u->username;
                                                                ?>"><span class="glyphicon glyphicon-trash"></span> Hapus</a>
                    </td>
                </tr>
            <?php
            }
            ?>
        </tbody>
    </table>
</div>