<div class="page-header">
    <h3>Barang</h3>
</div>
<a href="<?php echo base_url() . 'user/barang_add'; ?>" class="btn btn-primary btn-sm"><span class="glyphicon glyphicon-plus"></span>barang</a>
<br /><br />
<div class="table-responsive">
    <table class="table table-bordered table-striped table-hover" id="table-datatable">
        <thead>
            <tr>
                <th>No</th>
                <th>Kode Barang</th>
                <th>Nama Barang</th>
                <th>Kode Jenis</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            foreach ($barang as $b) {
            ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo $b->kd_barang ?></td>
                    <td><?php echo $b->nama_barang ?></td>
                    <td><?php echo $b->kd_jenis ?></td>
                    <td>
                        <a class="btn btn-warning btn-sm" href="<?php echo base_url() . 'user/barang_edit/' . $u->kd_barang;
                                                                ?>"><span class="glyphicon glyphicon-plus"></span> Edit</a>
                        <a class="btn btn-danger btn-sm" href="<?php echo base_url() . 'user/barang_hapus/' . $u->kd_barang;
                                                                ?>"><span class="glyphicon glyphicon-trash"></span> Hapus</a>
                    </td>
                </tr>
            <?php
            }
            ?>
        </tbody>
    </table>
</div>