<?php
defined('BASEPATH') or exit('No direct script access allowed');
class User extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        // cek login
        if ($this->session->userdata('status') != "login") {
            redirect(base_url() . 'welcome?pesan=belumlogin');
        }
    }
    function index()
    {
        $data['barang'] = $this->db->query("select * from 
        barang order by kd_barang desc")->result();
        $data['detail'] = $this->db->query("select * from detail 
        order by kd_detail desc")->result();
        $data['jenis_barang'] = $this->db->query("select * from jenis_barang 
        order by kd_jenis desc")->result();
        $this->load->view('user/header');
        $this->load->view('user/index', $data);
        $this->load->view('user/footer');
    }
    function logout()
    {
        $this->session->sess_destroy();
        redirect(base_url() . 'user?pesan=logout');
    }
}
