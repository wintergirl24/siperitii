<?php
class Data_user extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('t_master');
        $this->load->helper('url');
    }
    function index()
    {
        $data['user'] = $this->t_master->get_data('user')->result();

        $this->load->view('user/header');
        $this->load->view('data_user/index', $data);
        $this->load->view('user/footer');
    }
    function tambah()
    {
        $this->load->view('user/header');
        $this->load->view('data_user/tambah');
        $this->load->view('user/footer');
    }
    function tambah_aksi()
    {
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $nama = $this->input->post('nama');
        $alamat = $this->input->post('alamat');
        $email = $this->input->post('email');
        $no_hp = $this->input->post('no_hp');
        $level = $this->input->post('level');

        $data = array(
            'username' => $username,
            'password' => $password,
            'nama' => $nama,
            'alamat' => $alamat,
            'email' => $email,
            'no_hp' => $no_hp,
            'level' => $level,
        );
        $this->t_master->insert_data($data, 'user');
        redirect('data_user/index');
    }
    function hapus($id)
    {
        $where = array('username' => $id);
        $this->t_master->delete_data($where, 'user');
        redirect('data_user/index');
    }
    function ubah($id)
    {
        $where = array('username' => $id);
        $data['user'] = $this->t_master->edit_data($where, 'user')->row();

        $this->load->view('user/header');
        $this->load->view('data_user/ubah', $data);
        $this->load->view('user/footer');
    }
    function ubah_aksi()
    {
        $username = $this->input->post('username');
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $nama = $this->input->post('nama');
        $alamat = $this->input->post('alamat');
        $email = $this->input->post('email');
        $no_hp = $this->input->post('no_hp');
        $level = $this->input->post('level');
        $data = array(
            'username' => $username,
            'password' => $password,
            'nama' => $nama,
            'alamat' => $alamat,
            'email' => $email,
            'no_hp' => $no_hp,
            'level' => $level
        );
        $where = array(
            'username' => $username
        );
        $this->t_master->update_data($where, $data, 'user');
        redirect('data_user/index');
    }

    // LAPORAN
    function laporan()
    {
        $data['laporan'] = $this->db->query("select * from user")->result();
        // var_dump($data['laporan']);

        $this->load->view('data_user/laporan_filter', $data);
    }
}
